<!--begin::Sidebar-->
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
  <!--begin::Sidebar Brand-->
  <div class="sidebar-brand p-3">
    <a href="<?= BASE_URL . 'home' ?>" class="d-flex align-items-center text-decoration-none">
      <img
        src="<?= asset('dist/assets/img/AdminLTELogo.png') ?>"
        alt="Logo"
        class="brand-image opacity-75 shadow me-2"
        style="width:32px;height:32px;"
      />
      <span class="brand-text fw-light">Quản Lý Tour</span>
    </a>
  </div>
  <!--end::Sidebar Brand-->

  <!--begin::Sidebar Wrapper-->
  <div class="sidebar-wrapper">
    <nav class="mt-2">
      <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">

        <!-- Dashboard -->
        <li class="nav-item">
          <a href="<?= BASE_URL . 'home' ?>" class="nav-link">
            <i class="nav-icon bi bi-speedometer"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <!-- Quản lý Tour -->
        <li class="nav-item has-treeview">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-airplane-engines"></i>
            <p>
              Quản lý Tour
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= BASE_URL . '?act=tour-list' ?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i>
                <p>Danh sách Tour</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= BASE_URL . '?act=tour-add' ?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i>
                <p>Thêm Tour mới</p>
              </a>
            </li>
          </ul>
        </li>

        <!-- Quản lý Khách hàng -->
        <li class="nav-item has-treeview">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-people-fill"></i>
            <p>
              Quản lý Khách hàng
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= BASE_URL . '?act=customer-list' ?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i>
                <p>Danh sách Khách hàng</p>
              </a>
            </li>
          </ul>
        </li>

        <!-- Quản lý Phương tiện -->  <!-- THÊM MỚI -->
        <li class="nav-item has-treeview">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-truck-front-fill"></i>
            <p>
              Quản lý Phương tiện
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= BASE_URL . '?act=vehicle-list' ?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i>
                <p>Danh sách Phương tiện</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= BASE_URL . '?act=vehicle-add' ?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i>
                <p>Thêm Phương tiện</p>
              </a>
            </li>
          </ul>
        </li>

        <!-- Quản lý Người dùng (admin) -->
        <?php if (isAdmin()): ?>
        <li class="nav-item has-treeview">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-person-gear"></i>
            <p>
              Quản lý Người dùng
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= BASE_URL . '?act=user-list' ?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i>
                <p>Danh sách Người dùng</p>
              </a>
            </li>
          </ul>
        </li>
        <?php endif; ?>

        <li class="nav-header mt-3">HỆ THỐNG</li>
        <li class="nav-item">
          <a href="<?= BASE_URL . 'logout' ?>" class="nav-link">
            <i class="nav-icon bi bi-box-arrow-right"></i>
            <p>Đăng xuất</p>
          </a>
        </li>
      </ul>
    </nav>
  </div>
  <!--end::Sidebar Wrapper-->
</aside>
<!--end::Sidebar-->
