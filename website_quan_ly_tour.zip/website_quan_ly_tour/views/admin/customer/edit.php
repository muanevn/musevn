<?php view('partials.header', ['title' => $title]); ?>

<div class="container mt-4">

    <h2><?= $title ?></h2>

    <form action="index.php?act=customer-update" method="POST" class="mt-3">

        <input type="hidden" name="id" value="<?= $customer['id'] ?>">

        <div class="mb-3">
            <label>Họ tên</label>
            <input type="text" name="name" class="form-control" value="<?= $customer['name'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= $customer['email'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Số điện thoại</label>
            <input type="text" name="phone" class="form-control" value="<?= $customer['phone'] ?>" required>
        </div>

        <button class="btn btn-success">Cập nhật</button>

    </form>
</div>

<?php view('partials.footer'); ?>
