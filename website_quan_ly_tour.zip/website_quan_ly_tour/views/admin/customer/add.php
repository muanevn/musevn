<?php view('partials.header', ['title' => $title]); ?>

<div class="container mt-4">

    <h2><?= $title ?></h2>

    <form action="<?= BASE_URL ?>index.php?act=customer-store" method="POST" class="mt-3">

        <div class="mb-3">
            <label>Họ tên</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Số điện thoại</label>
            <input type="text" name="phone" class="form-control" required>
        </div>

        <button class="btn btn-primary">Thêm mới</button>

    </form>
</div>

<?php view('partials.footer'); ?>
