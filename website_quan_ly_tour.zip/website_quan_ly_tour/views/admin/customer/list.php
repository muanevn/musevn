<?php view('partials.header', ['title' => $title]); ?>

<style>
    .sidebar-admin {
        background-color: #2f3542;
        min-height: 100vh;
        padding: 20px 0;
    }

    .sidebar-admin .nav-link {
        color: #fff;
        padding: 10px 18px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 15px;
    }

    .sidebar-admin .nav-link:hover {
        background-color: #57606f;
        color: #fff;
    }

    .nav-item.has-treeview .nav-treeview {
        padding-left: 20px;
    }

    .nav-item.has-treeview.menu-open>a .nav-arrow {
        transform: rotate(90deg);
        transition: 0.2s ease;
    }

    .nav-arrow {
        transition: 0.2s ease;
    }
</style>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-12 col-md-2 sidebar-admin">
            <?php include __DIR__ . '/../../layouts/blocks/aside.php'; ?>
        </div>

        <!-- MAIN CONTENT -->
        <div class="col-12 col-md-10 mt-4">

            <h2 class="mb-4"><?= $title ?></h2>

            <?php if (!empty($_SESSION['flash_message'])): ?>
                <div class="alert alert-success shadow-sm">
                    <?= $_SESSION['flash_message'];
                    unset($_SESSION['flash_message']); ?>
                </div>
            <?php endif; ?>
            <a href="index.php?act=customer-add" class="btn btn-primary mb-3">
                + Thêm khách hàng
            </a>
            <div class="card shadow-sm">
                <div class="card-body p-0">

                    <table class="table table-hover table-bordered mb-0 align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th style="width: 60px;">ID</th>
                                <th style="width: 80px;">Ảnh</th>
                                <th>Tên khách hàng</th>
                                <th>Email</th>
                                <th>Điện thoại</th>
                                <th>Hành động</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($customers as $customer): ?>
                                <tr>
                                    <td class="fw-bold"><?= $customer['id'] ?></td>

                                    <td class="text-center">
                                        <?php if (!empty($customer['avatar'])): ?>
                                            <img src="<?= asset($customer['avatar']) ?>"
                                                class="rounded-circle border"
                                                style="width:50px;height:50px;object-fit:cover;">
                                        <?php else: ?>
                                            <div class="text-muted small fst-italic">
                                                Chưa có ảnh
                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    <td><?= $customer['name'] ?></td>
                                    <td><?= $customer['email'] ?></td>
                                    <td><?= $customer['phone'] ?></td>
                                    <td>
                                        <a href="index.php?act=customer-delete&id=<?= $customer['id'] ?>"
                                            class="btn btn-danger btn-sm"
                                            onclick="return confirm('Bạn chắc muốn xóa?')">
                                            Xóa
                                        </a>
                                        <a href="index.php?act=customer-edit&id=<?= $customer['id'] ?>"
                                            class="btn btn-warning btn-sm">
                                            Sửa
                                        </a>

                                    </td>

                                </tr>
                            <?php endforeach; ?>
                        </tbody>

                    </table>

                </div>
            </div>

        </div>
        <!-- END MAIN CONTENT -->

    </div>
</div>

<?php view('partials.footer'); ?>