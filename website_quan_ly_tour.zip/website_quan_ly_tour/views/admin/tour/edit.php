<?php view('partials.header', ['title' => $title ?? 'Sửa Tour']); ?>

<div class="container mt-4">

    <?php if (!empty($_SESSION['flash'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['flash']; unset($_SESSION['flash']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <h2 class="mb-4"><?= $title ?? 'Sửa Tour' ?></h2>

    <a href="<?= BASE_URL . '?act=tour-list' ?>" class="btn btn-secondary mb-3">
        <i class="bi bi-arrow-left"></i> Quay về danh sách
    </a>

    <form action="<?= BASE_URL . '?act=tour-edit&id=' . $tourData['id'] ?>" 
          method="post" enctype="multipart/form-data" 
          class="shadow-sm p-4 bg-white rounded">

        <!-- Tên tour -->
        <div class="mb-3">
            <label for="name" class="form-label">Tên Tour <span class="text-danger">*</span></label>
            <input type="text" 
                   name="name" 
                   id="name" 
                   class="form-control form-control-lg"
                   value="<?= htmlspecialchars($tourData['name']) ?>" 
                   required>
        </div>

        <!-- Giá -->
        <div class="mb-3">
            <label for="price" class="form-label">Giá <span class="text-danger">*</span></label>
            <input type="number" 
                   name="price" 
                   id="price" 
                   class="form-control form-control-lg"
                   value="<?= $tourData['price'] ?>" 
                   required>
        </div>

        <!-- Mô tả -->
        <div class="mb-3">
            <label for="description" class="form-label">Mô tả</label>
            <textarea name="description" 
                      id="description" 
                      class="form-control form-control-lg" 
                      rows="5"><?= htmlspecialchars($tourData['description']) ?></textarea>
        </div>

        <!-- Ảnh -->
        <div class="mb-3">
            <label for="image" class="form-label">Ảnh tour</label>

            <?php if (!empty($tourData['image'])): ?>
                <div class="mb-3">
                    <img id="currentImage" 
                         src="<?= asset($tourData['image']) ?>" 
                         alt="Ảnh hiện tại" 
                         style="max-width:200px; border-radius:8px;">
                </div>
            <?php endif; ?>

            <input type="file" 
                   name="image" 
                   id="image" 
                   class="form-control"
                   accept="image/*"
                   onchange="previewImage(event)">

            <div class="mt-3">
                <img id="preview"
                     src=""
                     alt="Xem trước"
                     style="max-width:200px; border-radius:8px; display:none;">
            </div>

            <small class="text-muted">
                Nếu chọn ảnh mới, ảnh cũ sẽ bị thay thế.
            </small>
        </div>

        <!-- Buttons -->
        <div class="d-flex gap-2 mt-3">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-save"></i> Cập nhật Tour
            </button>

            <a href="<?= BASE_URL . '?act=tour-list' ?>" class="btn btn-secondary btn-lg">
                <i class="bi bi-x-circle"></i> Hủy
            </a>
        </div>

    </form>
</div>

<script>
function previewImage(event) {
    const input = event.target;
    const preview = document.getElementById('preview');

    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.style.display = 'none';
        preview.src = '';
    }
}
</script>

<?php view('partials.footer'); ?>
