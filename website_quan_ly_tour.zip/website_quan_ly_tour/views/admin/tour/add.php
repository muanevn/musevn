<?php view('partials.header', ['title' => $title ?? 'Thêm Tour']); ?>

<style>
    .sidebar-admin {
        background-color: #2f3542;
        min-height: 100vh;
        padding: 20px 0;
    }
    .sidebar-admin .nav-link {
        color: #fff;
        padding: 10px 18px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 15px;
    }
    .sidebar-admin .nav-link:hover {
        background-color: #57606f;
        color: #fff;
    }
    .nav-item.has-treeview .nav-treeview {
    padding-left: 20px;
}

.nav-item.has-treeview.menu-open > a .nav-arrow {
    transform: rotate(90deg);
    transition: 0.2s ease;
}

.nav-arrow {
    transition: 0.2s ease;
}

</style>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-12 col-md-2 sidebar-admin">
            <?php include __DIR__ . '/../../layouts/blocks/aside.php'; ?>
        </div>

        <!-- MAIN CONTENT -->
        <div class="col-12 col-md-10 mt-4">

            <h2 class="mb-4"><?= $title ?? 'Thêm Tour mới' ?></h2>

            <form action="?act=tour-store" method="POST" enctype="multipart/form-data"
                  class="shadow-sm p-4 bg-white rounded">

                <div class="mb-3">
                    <label for="name" class="form-label">Tên Tour <span class="text-danger">*</span></label>
                    <input type="text" name="name" id="name" class="form-control form-control-lg"
                           placeholder="Nhập tên tour..." required>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Giá <span class="text-danger">*</span></label>
                    <input type="number" name="price" id="price" class="form-control form-control-lg"
                           placeholder="Nhập giá tour..." required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Mô tả</label>
                    <textarea name="description" id="description" class="form-control form-control-lg"
                              rows="5" placeholder="Nhập mô tả tour..."></textarea>
                </div>

                <div class="mb-3">
                    <label for="image" class="form-label">Ảnh tour</label>
                    <input type="file" name="image" id="image" class="form-control"
                           accept="image/*" onchange="previewImage(event)">
                    <div class="mt-3">
                        <img id="preview" src="" alt="Preview"
                             style="max-width: 200px; display: none; border-radius: 8px;">
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="bi bi-save"></i> Lưu
                    </button>

                    <a href="?act=tour-list" class="btn btn-secondary btn-lg">
                        <i class="bi bi-x-circle"></i> Hủy
                    </a>
                </div>

            </form>

        </div> <!-- END MAIN CONTENT -->
    </div>
</div>

<script>
function previewImage(event) {
    const input = event.target;
    const preview = document.getElementById('preview');

    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.src = '';
        preview.style.display = 'none';
    }
}
</script>

<?php view('partials.footer'); ?>
