<?php view('partials.header', ['title' => $title ?? 'Danh sách Tour']); ?>

<style>
    /* Sidebar dark giống hệ thống */
    .sidebar-admin {
        background-color: #2f3542;
        min-height: 100vh;
        padding: 20px 0;
    }
    .sidebar-admin .nav-link {
        color: #fff;
        padding: 10px 18px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 15px;
    }
    .sidebar-admin .nav-link:hover {
        background-color: #57606f;
        color: #fff;
    }
</style>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-12 col-md-2 sidebar-admin">
            <?php include __DIR__ . '/../../layouts/blocks/aside.php'; ?>
        </div>

        <!-- MAIN CONTENT -->
        <div class="col-12 col-md-10 mt-4">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2><?= $title ?? 'Danh sách Tour' ?></h2>

                <a href="<?= BASE_URL . '?act=tour-add' ?>" class="btn btn-success shadow-sm">
                    <i class="bi bi-plus-lg"></i> Thêm Tour mới
                </a>
            </div>

            <!-- FLASH MESSAGE -->
            <?php if (!empty($flash)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- TABLE -->
            <div class="table-responsive shadow-sm rounded bg-white p-2">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Ảnh</th>
                            <th>Tên Tour</th>
                            <th>Giá</th>
                            <th>Mô tả</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php if (!empty($tours)): ?>
                            <?php foreach ($tours as $tour): ?>
                                <tr>
                                    <td><?= $tour['id'] ?></td>

                                    <td>
                                        <?php 
                                            $imagePath = __DIR__ . '/../../public/' . $tour['image'];
                                            if (!empty($tour['image']) && file_exists($imagePath)): 
                                        ?>
                                            <img src="<?= BASE_URL . 'public/' . $tour['image'] ?>"
                                                alt="<?= htmlspecialchars($tour['name']) ?>"
                                                style="width:80px; height:auto; border-radius:5px;">
                                        <?php else: ?>
                                            <span class="text-muted">Chưa có ảnh</span>
                                        <?php endif; ?>
                                    </td>

                                    <td><?= htmlspecialchars($tour['name']) ?></td>
                                    <td><?= number_format($tour['price'], 0, ',', '.') ?>₫</td>
                                    <td><?= htmlspecialchars($tour['description']) ?></td>

                                    <td>
                                        <a href="<?= BASE_URL . '?act=tour-edit&id=' . $tour['id'] ?>" 
                                           class="btn btn-sm btn-warning shadow-sm mb-1">
                                            <i class="bi bi-pencil-square"></i> Sửa
                                        </a>

                                        <a href="<?= BASE_URL . '?act=tour-delete&id=' . $tour['id'] ?>" 
                                           class="btn btn-sm btn-danger shadow-sm"
                                           onclick="return confirm('Bạn có chắc muốn xóa?')">
                                            <i class="bi bi-trash"></i> Xóa
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>

                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">Chưa có tour nào.</td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

        </div> <!-- end col-10 -->

    </div> <!-- end row -->
</div> <!-- end container-fluid -->

<?php view('partials.footer'); ?>
