<?php view('partials.header', ['title' => $title]); ?>

<div class="container mt-4">
    <h2>Thêm phương tiện</h2>

    <form method="POST" action="index.php?act=vehicle-store">

        <div class="mb-3">
            <label>Tên phương tiện</label>
            <input name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Loại</label>
            <input name="type" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Biển số</label>
            <input name="license_plate" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Số ghế</label>
            <input type="number" name="seats" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Trạng thái</label>
            <select name="status" class="form-control">
                <option value="Đang hoạt động">Đang hoạt động</option>
                <option value="Bảo trì">Bảo trì</option>
                <option value="Ngừng hoạt động">Ngừng hoạt động</option>
            </select>
        </div>

        <button class="btn btn-success">Lưu</button>
    </form>
</div>

<?php view('partials.footer'); ?>
