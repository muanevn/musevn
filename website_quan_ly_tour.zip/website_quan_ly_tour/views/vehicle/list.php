<?php view('partials.header', ['title' => $title ?? 'Danh sách Phương tiện']); ?>

<style>
    /* Sidebar dark giống hệ thống */
    .sidebar-admin {
        background-color: #2f3542;
        min-height: 100vh;
        padding: 20px 0;
    }
    .sidebar-admin .nav-link {
        color: #fff;
        padding: 10px 18px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 15px;
    }
    .sidebar-admin .nav-link:hover {
        background-color: #57606f;
        color: #fff;
    }
</style>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-12 col-md-2 sidebar-admin">
            <?php include __DIR__ . '/../layouts/blocks/aside.php'; ?>
        </div> <!-- 🔥 THẺ NÀY BỊ THIẾU -->

        <!-- MAIN CONTENT -->
        <div class="col-12 col-md-10 mt-4">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2><?= $title ?? 'Danh sách Phương tiện' ?></h2>

                <a href="<?= BASE_URL . '?act=vehicle-create' ?>" class="btn btn-success shadow-sm">
                    <i class="bi bi-plus-lg"></i> Thêm phương tiện
                </a>
            </div>

            <!-- FLASH MESSAGE -->
            <?php if (!empty($flash)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($flash) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- TABLE -->
            <div class="table-responsive shadow-sm rounded bg-white p-2">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Tên</th>
                            <th>Loại</th>
                            <th>Biển số</th>
                            <th>Số ghế</th>
                            <th>Trạng thái</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (!empty($vehicles)): ?>
                            <?php foreach ($vehicles as $v): ?>
                                <tr>
                                    <td><?= $v['id'] ?></td>
                                    <td><?= htmlspecialchars($v['name']) ?></td>
                                    <td><?= htmlspecialchars($v['type']) ?></td>
                                    <td><?= htmlspecialchars($v['license_plate']) ?></td>
                                    <td><?= htmlspecialchars($v['seats']) ?></td>
                                    <td>
                                        <?php if ($v['status'] == 'available'): ?>
                                            <span class="badge bg-success">Sẵn sàng</span>
                                        <?php elseif ($v['status'] == 'busy'): ?>
                                            <span class="badge bg-warning text-dark">Đang chạy</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Bảo trì</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <a href="<?= BASE_URL . '?act=vehicle-edit&id=' . $v['id'] ?>" 
                                           class="btn btn-sm btn-warning shadow-sm mb-1">
                                            <i class="bi bi-pencil-square"></i> Sửa
                                        </a>

                                        <a href="<?= BASE_URL . '?act=vehicle-delete&id=' . $v['id'] ?>" 
                                           class="btn btn-sm btn-danger shadow-sm"
                                           onclick="return confirm('Bạn có chắc muốn xóa?')">
                                            <i class="bi bi-trash"></i> Xóa
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>

                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">Chưa có phương tiện nào.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div><!-- end col-10 -->

    </div><!-- end row -->
</div><!-- end container-fluid -->

<?php view('partials.footer'); ?>
