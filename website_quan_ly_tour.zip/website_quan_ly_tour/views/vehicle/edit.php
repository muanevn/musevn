<?php view('partials.header', ['title' => $title]); ?>

<div class="container mt-4">
    <h2>Sửa phương tiện</h2>

    <form method="POST" action="index.php?act=vehicle-update">

        <input type="hidden" name="id" value="<?= $vehicle['id'] ?>">

        <div class="mb-3">
            <label>Tên phương tiện</label>
            <input name="name" class="form-control" 
                   value="<?= $vehicle['name'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Loại</label>
            <input name="type" class="form-control" 
                   value="<?= $vehicle['type'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Biển số</label>
            <input name="license_plate" class="form-control" 
                   value="<?= $vehicle['license_plate'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Số ghế</label>
            <input type="number" name="seats" class="form-control" 
                   value="<?= $vehicle['seats'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Trạng thái</label>
            <select name="status" class="form-control">
                <option value="Đang hoạt động" <?= $vehicle['status']=='Đang hoạt động'?'selected':'' ?>>Đang hoạt động</option>
                <option value="Bảo trì" <?= $vehicle['status']=='Bảo trì'?'selected':'' ?>>Bảo trì</option>
                <option value="Ngừng hoạt động" <?= $vehicle['status']=='Ngừng hoạt động'?'selected':'' ?>>Ngừng hoạt động</option>
            </select>
        </div>

        <button class="btn btn-primary">Cập nhật</button>
    </form>
</div>

<?php view('partials.footer'); ?>
