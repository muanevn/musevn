<?php
// Sử dụng layout auth và truyền nội dung vào
ob_start();
?>
<!--begin::Login Content-->
<div class="login-wrapper d-flex justify-content-center align-items-center" style="
    min-height: 100vh;
    background: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1350&q=80') no-repeat center center/cover;
    position: relative;
">
    <!-- Overlay cam nhạt để chữ nổi bật -->
    <div style="
        position: absolute;
        top:0; left:0; right:0; bottom:0;
        background: rgba(255,165,0,0.3); /* cam nhạt overlay */
        z-index: 1;
    "></div>

    <div class="col-12 col-md-8 col-lg-5 col-xl-4" style="position: relative; z-index: 2;">
        <div class="card login-card shadow-lg border-0" style="background: rgba(255,255,255,0.95);">
            <!-- Header -->
            <div class="login-header text-center mb-4">
                <!-- Logo Text -->
                <div style="
                    font-size: 36px;
                    font-weight: bold;
                    color: #ffffffff;
                    letter-spacing: 2px;
                ">FPT <span style="font-weight: normal;">Polytechnic</span></div>
                <h2 class="mt-2 fw-bold text-orange">FPOLY</h2>
                <div class="mt-1 fw-light fst-italic" style="font-size: 1rem; color: #555;">
                    Hệ thống quản lý tour chuyên nghiệp
                </div>
            </div>

            <div class="card-body">
                <h4 class="card-title text-center mb-4 fw-bold card-title-login text-orange">
                    Đăng nhập để tiếp tục
                </h4>

                <?php if (!empty($errors)): ?>
                <div class="alert alert-danger fade show" role="alert">
                    <div class="d-flex align-items-center mb-2">
                        <i class="bi bi-exclamation-circle-fill me-2 fs-5"></i>
                        <strong>Lỗi đăng nhập</strong>
                    </div>
                    <ul class="mb-0 ps-3">
                        <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form action="<?= BASE_URL ?>check-login" method="post" autocomplete="on" novalidate>
                    <input type="hidden" name="redirect" value="<?= $redirect ?? BASE_URL . 'home' ?>" />

                    <!-- Email -->
                    <div class="mb-3">
                        <label for="loginEmail" class="form-label fw-semibold text-dark">
                            Email
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-orange text-white"><i class="bi bi-envelope"></i></span>
                            <input type="email"
class="form-control"
                                   id="loginEmail"
                                   name="email"
                                   value="<?= htmlspecialchars($email ?? '') ?>"
                                   placeholder="Nhập email"
                                   required
                                   autofocus />
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="mb-2">
                        <label for="loginPassword" class="form-label fw-semibold text-dark">
                            Mật khẩu
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-orange text-white"><i class="bi bi-lock-fill"></i></span>
                            <input type="password"
                                   class="form-control"
                                   id="loginPassword"
                                   name="password"
                                   placeholder="Nhập mật khẩu"
                                   required
                                   autocomplete="current-password"/>
                            <button type="button" class="btn btn-outline-secondary btn-sm" tabindex="-1" id="togglePassword" title="Hiện/ẩn mật khẩu">
                                <i class="bi bi-eye" id="togglePasswordIcon"></i>
                            </button>
                        </div>
                    </div>

                    <div class="mb-4 d-flex justify-content-between align-items-center">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="1" id="rememberMe" name="remember_me">
                            <label class="form-check-label" for="rememberMe">
                                Ghi nhớ tài khoản
                            </label>
                        </div>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-orange btn-lg text-white">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Đăng nhập
                        </button>
                    </div>
                </form>

                <div class="login-divider my-3" style="border-top: 1px solid #ff7300;"></div>

                <div class="text-center">
                    <a href="<?= BASE_URL ?>" class="text-decoration-none text-orange fw-semibold">
                        <i class="bi bi-arrow-left me-2"></i>
                        Quay về trang chủ
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Custom Styles -->
<style>
/* Màu cam chủ đạo */
.text-orange {
    color: #ffffffff !important;
}
.bg-orange {
    background-color: #ff7300 !important;
}
.btn-orange {
background-color: #ff7300;
    border-color: #ff7300;
}
.btn-orange:hover {
    background-color: #e06600;
    border-color: #e06600;
}
.login-card {
    border-radius: 15px;
}
</style>
<!--end::Login Content-->
<?php
$content = ob_get_clean();

// Hiển thị layout auth với nội dung
view('layouts.AuthLayout', [
    'title' => $title ?? 'Đăng nhập',
    'content' => $content,
    'extraJs' => ['js/login.js'],
]);
?>