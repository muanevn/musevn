<?php
ob_start();
?>
<style>
  :root {
    --main-red: #ff1a1a;
    --main-red-dark: #d90000;
    --main-red-light: #ff4d4d;
    --text-dark: #222;
    --card-radius: 1.5rem;
    --card-shadow: 0 10px 40px rgba(255,0,0,0.15);
    --alert-shadow: 0 6px 18px rgba(0,0,0,0.06);
    --transition-speed: 0.25s;
}

/* ===== Body ===== */
body {
    background: linear-gradient(135deg, #ffcccc, #ffe6e6);
    font-family: "Poppins", sans-serif;
    color: var(--text-dark);
}

/* ===== Card ===== */
.card {
    border: none;
    border-radius: var(--card-radius);
    box-shadow: var(--card-shadow);
    overflow: hidden;
    transition: transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 50px rgba(255,0,0,0.2);
}

/* Card Header */
.card-header {
    padding: 2rem 1.5rem;
    color: #fff;
    background: linear-gradient(135deg, var(--main-red), var(--main-red-light));
}

.card-header h1 {
    font-size: 2rem;
    font-weight: 800;
    margin-bottom: 0.2rem;
}

.card-header h5 {
    font-size: 1.2rem;
    font-weight: 500;
}

/* Card Body */
.card-body {
    padding: 2rem 1.5rem;
}

/* Alerts */
.alert {
    display: flex;
    align-items: center;
    padding: 1rem 1.5rem;
    border-radius: 1rem;
    box-shadow: var(--alert-shadow);
    font-size: 1rem;
}

.alert i {
    font-size: 2rem;
    margin-right: 1rem;
}

.alert-success {
    background: #e6f7ed;
    color: #14532d;
}

.alert-warning {
    background: #fff4e5;
    color: #78350f;
}

/* List group / account info */
.list-group {
    border-radius: 1rem;
    overflow: hidden;
    box-shadow: var(--alert-shadow);
}

.list-group-item {
    padding: 1rem 1.5rem;
    transition: background var(--transition-speed) ease, transform var(--transition-speed) ease;
    cursor: default;
}

.list-group-item:hover {
    background: rgba(255, 26, 26, 0.05);
    transform: translateY(-2px);
}

.list-group-item h5 {
    font-weight: 600;
    margin-bottom: 0.2rem;
}

.list-group-item p {
    margin-bottom: 0;
}

/* Icons */
.bi {
    vertical-align: middle;
}

/* Responsive */
@media (max-width: 768px) {
    .card-header {
        padding: 1.5rem 1rem;
    }
    .card-body {
        padding: 1.5rem 1rem;
    }
    .card-header h1 {
        font-size: 1.5rem;
    }
    .card-header h5 {
        font-size: 1rem;
    }
    .alert i {
        font-size: 1.5rem;
    }
}

</style>
<!--begin::Row-->
<div class="row g-4">
  <div class="col-12">
    <div class="card shadow-lg border-0 rounded-4">
      <div class="card-header text-white p-4" style="background: linear-gradient(135deg, #ff1a1a, #ff6a6a);">
        <h1 class="fw-bold mb-1"><i class="bi bi-geo-alt-fill me-2"></i>Chào mừng!</h1>
        <h5 class="fw-normal">Hệ thống quản lý tour du lịch</h5>
      </div>
      <div class="card-body p-4">

        <?php if (isLoggedIn()): ?>
<div class="alert alert-success d-flex align-items-center shadow-sm rounded-3 mb-4">
            <i class="bi bi-check-circle-fill fs-2 me-3"></i>
            <div>
              <strong>Đăng nhập thành công!</strong><br>
              Xin chào, <strong><?= htmlspecialchars($user->name) ?></strong>! 
              Quyền của bạn: <strong><?= $user->isAdmin() ? 'Admin' : 'Hướng dẫn viên' ?></strong>.
            </div>
          </div>

          <div class="account-info mt-4">
            <h3 class="mb-3 fw-semibold"><i class="bi bi-person-badge-fill me-2 text-danger"></i>Thông tin tài khoản</h3>
            <div class="list-group shadow-sm rounded-3">
              <div class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                  <h5 class="mb-1"><i class="bi bi-envelope-fill me-2 text-danger"></i>Email</h5>
                  <p class="mb-0"><?= htmlspecialchars($user->email) ?></p>
                </div>
              </div>
              <div class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                  <h5 class="mb-1"><i class="bi bi-shield-fill-check me-2 text-danger"></i>Vai trò</h5>
                  <p class="mb-0"><?= $user->isAdmin() ? 'Quản trị viên' : 'Hướng dẫn viên' ?></p>
                </div>
              </div>
            </div>
          </div>

        <?php else: ?>
          <div class="alert alert-warning d-flex align-items-center shadow-sm rounded-3">
            <i class="bi bi-exclamation-triangle-fill fs-2 me-3"></i>
            <div>
              <strong>Chưa đăng nhập</strong><br>
              Vui lòng <a href="<?= BASE_URL ?>?act=login" class="alert-link">đăng nhập</a> để sử dụng đầy đủ chức năng.
            </div>
          </div>
        <?php endif; ?>

      </div>
    </div>
  </div>
</div>
<!--end::Row-->

<?php
$content = ob_get_clean();

view('layouts.AdminLayout', [
    'title' => $title ?? 'Trang chủ - Website Quản Lý Tour',
    'pageTitle' => 'Trang chủ',
    'content' => $content,
    'breadcrumb' => [
        ['label' => 'Trang chủ', 'url' => BASE_URL . 'home', 'active' => true],
    ],
]);
?>