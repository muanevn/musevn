<aside class="sidebar d-flex flex-column p-3 shadow-sm">
    <a href="<?= BASE_URL . 'home' ?>" class="d-flex align-items-center mb-3 text-decoration-none text-white">
        <img src="<?= asset('dist/assets/img/AdminLTELogo.png') ?>" alt="Logo" class="me-2" style="width:32px;">
        <span class="fs-5 fw-light">Quản Lý Tour</span>
    </a>
    <ul class="nav nav-pills flex-column mb-auto">
        <li><a href="<?= BASE_URL . 'home' ?>" class="nav-link text-white"><i class="bi bi-speedometer"></i> Dashboard</a></li>
        <li><a href="<?= BASE_URL . '?act=tour-list' ?>" class="nav-link text-white"><i class="bi bi-airplane-engines"></i> Tour</a></li>
        <li><a href="<?= BASE_URL . '?act=customer-list' ?>" class="nav-link text-white"><i class="bi bi-people-fill"></i> Khách hàng</a></li>
        
        <?php if(isAdmin()): ?>
        <li><a href="<?= BASE_URL . '?act=user-list' ?>" class="nav-link text-white"><i class="bi bi-person-gear"></i> Người dùng</a></li>
        <?php endif; ?>
        <li><a href="<?= BASE_URL . 'logout' ?>" class="nav-link text-white"><i class="bi bi-box-arrow-right"></i> Đăng xuất</a></li>
    </ul>
</aside>
