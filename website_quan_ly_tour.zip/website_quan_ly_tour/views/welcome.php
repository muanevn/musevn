<?php
ob_start();
?>
<!--begin::Main Content-->
<div class="welcome-wrapper d-flex justify-content-center align-items-center" style="
    min-height: 100vh;
    background: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1350&q=80') no-repeat center center/cover;
    position: relative;
">
  <!-- Overlay cam nhạt để chữ nổi bật -->
  <div style="
      position: absolute;
      top:0; left:0; right:0; bottom:0;
      background: rgba(255,165,0,0.3); /* cam nhạt overlay */
      z-index: 1;
  "></div>

  <!-- Card chính -->
  <div class="welcome-card shadow-lg p-5 rounded-4" style="
      max-width: 900px;
      width: 100%;
      background: rgba(255,255,255,0.95);
      color: #333;
      position: relative;
      z-index: 2;
      animation: fadeIn 1s ease;
  ">
    
    <!-- Logo + Header -->
    <div class="text-center mb-4">
      <!-- Logo text: FPT Polytechnic -->
      <div style="
          font-size: 48px;
          font-weight: bold;
          color: #ff7300; /* màu cam chủ đạo */
          letter-spacing: 2px;
      ">
          FPT <span style="font-weight: normal;">Polytechnic</span>
      </div>
      <h1 class="mt-3 fw-bold text-orange">FPOLY</h1>
      <p style="color: #333;">Hệ thống quản lý tour du lịch chuyên nghiệp, trực quan</p>
    </div>

    <!-- Alert -->
    <div class="alert border-start border-4 border-orange shadow-sm" role="alert" style="background: rgba(255,244,230,0.95); color: #333;">
      <h4 class="alert-heading text-orange"><i class="bi bi-info-circle me-2"></i>Thông báo</h4>
      <p>Để trải nghiệm đầy đủ chức năng, vui lòng đăng nhập vào hệ thống.</p>
      <div class="d-grid mt-3">
        <a href="<?= BASE_URL ?>login" class="btn" style="background-color: #ff7300; color: #fff;">
          <i class="bi bi-box-arrow-in-right me-2"></i> Đăng nhập ngay
        </a>
      </div>
    </div>

    <!-- Features -->
    <div class="row mt-5 text-center g-4">
      <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 feature-card" style="background: rgba(255,245,230,0.95); transition: transform 0.3s;">
          <div class="card-body">
            <i class="bi bi-airplane-engines display-4 text-orange mb-3 animate-bounce"></i>
            <h5 class="card-title fw-bold text-orange">Quản lý Tour</h5>
            <p class="card-text" style="color: #333;">Tạo, chỉnh sửa và theo dõi các tour du lịch chuyên nghiệp.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 feature-card" style="background: rgba(255,245,230,0.95); transition: transform 0.3s;">
          <div class="card-body">
            <i class="bi bi-people display-4 text-orange mb-3 animate-bounce"></i>
            <h5 class="card-title fw-bold text-orange">Quản lý Khách hàng</h5>
<p class="card-text" style="color: #333;">Theo dõi khách hàng, đặt tour và quản lý thông tin dễ dàng.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100 feature-card" style="background: rgba(255,245,230,0.95); transition: transform 0.3s;">
          <div class="card-body">
            <i class="bi bi-graph-up display-4 text-orange mb-3 animate-bounce"></i>
            <h5 class="card-title fw-bold text-orange">Báo cáo & Thống kê</h5>
            <p class="card-text" style="color: #333;">Xem báo cáo doanh thu và thống kê trực quan, dễ hiểu.</p>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- Animations -->
<style>
@keyframes fadeIn {
  from {opacity: 0; transform: translateY(20px);}
  to {opacity: 1; transform: translateY(0);}
}
@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}
.animate-bounce {
  animation: bounce 2s infinite;
}
.feature-card:hover {
  transform: translateY(-5px);
}
/* Màu cam chủ đạo */
.text-orange {
  color: #ff7300 !important;
}
.border-orange {
  border-color: #ff7300 !important;
}
</style>
<!--end::Main Content-->
<?php
$content = ob_get_clean();
view('layouts.AuthLayout', [
    'title' => $title ?? 'Website Quản Lý Tour Du Lịch - Orange Theme',
    'content' => $content,
]);
?>
