<?php

// Hàm kết nối tới cơ sở dữ liệu MySQL
function getDB()
{
    static $pdo = null;
    static $dbConfig = null;

    if ($pdo !== null) {
        return $pdo;
    }

    if ($dbConfig === null) {
        $config = require BASE_PATH . '/config/config.php';
        $dbConfig = $config['db'];
    }

    try {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            $dbConfig['host'],
            $dbConfig['name'],
            $dbConfig['charset']
        );

        $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);

        return $pdo;
    } catch (PDOException $e) {
        error_log('Database connection failed: ' . $e->getMessage());
        return null;
    }
}

// =========================
// FIX – TƯƠNG THÍCH CODE CŨ
// =========================

// Tour.php đang gọi connectDB()
// nên tạo alias này để khỏi sửa model
function connectDB() {
    return getDB();
}
