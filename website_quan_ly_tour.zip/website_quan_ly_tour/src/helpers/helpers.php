<?php

// Hàm xác định đường dẫn tuyệt đối tới file view tương ứng
function view_path(string $view): string
{
    $normalized = str_replace('.', DIRECTORY_SEPARATOR, $view);

    // Đường dẫn chuẩn
    $primary = BASE_PATH . '/views/' . $normalized . '.php';

    // Fallback: /views/layouts/blocks/
    $fallback = BASE_PATH . '/views/layouts/blocks/' . basename($normalized) . '.php';

    if (file_exists($primary)) {
        return $primary;
    }

    if (file_exists($fallback)) {
        return $fallback;
    }

    // Nếu vẫn không tìm thấy -> quăng lỗi
    throw new RuntimeException("View '{$view}' not found at {$primary} OR {$fallback}");
}

// Hàm include view
function view(string $view, array $data = []): void
{
    $file = view_path($view);

    extract($data, EXTR_OVERWRITE);
    include $file;
}

// ====== KHÔNG ĐỤNG TỚI PHẦN DƯỚI (GIỮ NGUYÊN) ======

function block_path(string $block): string
{
    return BASE_PATH . '/views/layouts/blocks/' . $block . '.php';
}

function block(string $block, array $data = []): void
{
    $file = block_path($block);

    if (!file_exists($file)) {
        throw new RuntimeException("Block '{$block}' not found at {$file}");
    }

    extract($data, EXTR_OVERWRITE);
    include $file;
}

function asset(string $path): string
{
    $trimmed = ltrim($path, '/');
    return rtrim(BASE_URL, '/') . '/public/' . $trimmed;
}

function startSession()
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function loginUser($user)
{
    startSession();
    $_SESSION['user_id'] = $user->id;
    $_SESSION['user_name'] = $user->name;
    $_SESSION['user_email'] = $user->email;
    $_SESSION['user_role'] = $user->role;
}

function logoutUser()
{
    startSession();
    session_destroy();
}

function isLoggedIn()
{
    startSession();
    return isset($_SESSION['user_id']);
}

function getCurrentUser()
{
    if (!isLoggedIn()) return null;

    return new User([
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'],
        'email' => $_SESSION['user_email'],
        'role' => $_SESSION['user_role'],
    ]);
}

function isAdmin()
{
    $u = getCurrentUser();
    return $u && $u->isAdmin();
}

function isGuide()
{
    $u = getCurrentUser();
    return $u && $u->isGuide();
}

function requireLogin($redirectUrl = null)
{
    if (!isLoggedIn()) {
        $redirect = $redirectUrl ?: $_SERVER['REQUEST_URI'];
        header('Location: ' . BASE_URL . '?act=login&redirect=' . urlencode($redirect));
        exit;
    }
}

function requireAdmin()
{
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . BASE_URL);
        exit;
    }
}

function requireGuideOrAdmin()
{
    requireLogin();
    if (!isGuide() && !isAdmin()) {
        header('Location: ' . BASE_URL);
        exit;
    }
}
function redirect($url) {
    header("Location: " . $url);
    exit;
}