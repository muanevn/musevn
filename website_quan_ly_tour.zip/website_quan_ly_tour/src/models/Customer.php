<?php
class Customer {
    private $db;
    public function __construct() {
        $this->db = connectDB();
    }

    public function getAll() {
        $stmt = $this->db->query("SELECT * FROM customers ORDER BY id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Thêm khách hàng
    public function insert($data) {
        $sql = "INSERT INTO customers (name, email, phone, created_at)
                VALUES (:name, :email, :phone, NOW())";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':name'  => $data['name'],
            ':email' => $data['email'],
            ':phone' => $data['phone']
        ]);
    }

    // Xóa khách hàng
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM customers WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
    public function find($id) {
    $stmt = $this->db->prepare("SELECT * FROM customers WHERE id = :id");
    $stmt->execute([':id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
public function update($id, $data) {
    $sql = "UPDATE customers 
            SET name = :name, email = :email, phone = :phone
            WHERE id = :id";

    $stmt = $this->db->prepare($sql);

    return $stmt->execute([
        ':id'    => $id,
        ':name'  => $data['name'],
        ':email' => $data['email'],
        ':phone' => $data['phone']
    ]);
}

}
