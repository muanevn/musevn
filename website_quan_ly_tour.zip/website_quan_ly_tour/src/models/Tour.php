{"variant":"standard","id":"56291"}
<?php
require_once __DIR__ . '/../helpers/database.php';

class Tour {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    // Lấy tất cả tour
    public function getAll() {
        $stmt = $this->db->query("SELECT * FROM tours ORDER BY id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lấy tour theo ID
    public function getById($id) {
        $stmt = $this->db->prepare("SELECT * FROM tours WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Tạo tour mới
    public function create($data) {
        $stmt = $this->db->prepare(
            "INSERT INTO tours(name, price, description, image) 
             VALUES(:name, :price, :description, :image)"
        );

        return $stmt->execute([
            'name'        => $data['name'] ?? null,
            'price'       => $data['price'] ?? null,
            'description' => $data['description'] ?? null,
            'image'       => $data['image'] ?? null
        ]);
    }

    // Cập nhật tour
    public function update($id, $data) {
        $stmt = $this->db->prepare(
            "UPDATE tours SET 
                name = :name,
                price = :price,
                description = :description,
                image = :image
             WHERE id = :id"
        );

        return $stmt->execute([
            'name'        => $data['name'] ?? null,
            'price'       => $data['price'] ?? null,
            'description' => $data['description'] ?? null,
            'image'       => $data['image'] ?? null,
            'id'          => $id
        ]);
    }

    // Xóa tour
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM tours WHERE id = :id");
        try {
            return $stmt->execute(['id' => $id]);
        } catch (PDOException $e) {
            return false; // nếu lỗi FK
        }
    }
}
?>
