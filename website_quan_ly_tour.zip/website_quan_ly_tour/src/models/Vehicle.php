<?php
require_once __DIR__ . '/../helpers/database.php';

class Vehicle {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function getAll() {
        return $this->db->query("SELECT * FROM vehicles ORDER BY id DESC")
                        ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find($id) {
        $stmt = $this->db->prepare("SELECT * FROM vehicles WHERE id=?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($name, $type, $plate, $seats, $status) {
        $stmt = $this->db->prepare(
            "INSERT INTO vehicles(name,type,license_plate,seats,status)
             VALUES (?,?,?,?,?)"
        );
        return $stmt->execute([$name, $type, $plate, $seats, $status]);
    }

    public function update($id, $name, $type, $plate, $seats, $status) {
        $stmt = $this->db->prepare(
            "UPDATE vehicles 
             SET name=?,type=?,license_plate=?,seats=?,status=? 
             WHERE id=?"
        );
        return $stmt->execute([$name, $type, $plate, $seats, $status, $id]);
    }

    public function delete($id) {
        return $this->db->prepare("DELETE FROM vehicles WHERE id=?")
                        ->execute([$id]);
    }
}
