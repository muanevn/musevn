<?php
require_once __DIR__ . '/../models/Vehicle.php';

class VehicleController {
    private $vehicleModel;

    public function __construct() {
        $this->vehicleModel = new Vehicle();
    }

    public function list() {
        $vehicles = $this->vehicleModel->getAll();
        $title = "Danh sách phương tiện";
        require __DIR__ . '/../../views/vehicle/list.php';
    }

    public function create() {
        $title = "Thêm phương tiện";
        require __DIR__ . '/../../views/vehicle/create.php';
    }

    public function store() {
        $this->vehicleModel->create(
            $_POST['name'],
            $_POST['type'],
            $_POST['license_plate'],
            $_POST['seats'],
            $_POST['status']
        );
        redirect('index.php?act=vehicle-list');
    }

    public function edit() {
        $id = $_GET['id'] ?? null;
        if (!$id) redirect('index.php?act=vehicle-list');

        $vehicle = $this->vehicleModel->find($id);
        $title = "Sửa phương tiện";
        require __DIR__ . '/../../views/vehicle/edit.php';
    }

    public function update() {
        $this->vehicleModel->update(
            $_POST['id'],
            $_POST['name'],
            $_POST['type'],
            $_POST['license_plate'],
            $_POST['seats'],
            $_POST['status']
        );
        redirect('index.php?act=vehicle-list');
    }

    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id) $this->vehicleModel->delete($id);
        redirect('index.php?act=vehicle-list');
    }
}
