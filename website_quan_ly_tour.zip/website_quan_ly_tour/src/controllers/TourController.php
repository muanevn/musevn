<?php
class TourController {
    private $tour;

    public function __construct() {
        $this->tour = new Tour();
        startSession(); // Đảm bảo session luôn sẵn sàng cho flash messages
    }

    // ===== DANH SÁCH TOUR =====
    public function list() {
        $tours = $this->tour->getAll();
        $title = "Danh sách Tour";

        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);

        view('admin.tour.list', compact('tours', 'title', 'flash'));
    }

    // ===== THÊM TOUR =====
    public function add() {
        $title = "Thêm Tour mới";
        view('admin.tour.add', compact('title'));
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location:?act=tour-add'); exit;
        }

        $data = [
            'name' => $_POST['name'] ?? '',
            'price' => $_POST['price'] ?? 0,
            'description' => $_POST['description'] ?? '',
            'image' => null
        ];

        // Upload ảnh nếu có
        if (!empty($_FILES['image']['name'])) {
            $uploadDir = __DIR__ . '/../../public/uploads/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '.' . $ext;
            $target = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                $data['image'] = 'uploads/' . $filename;
            }
        }

        $this->tour->create($data);

        $_SESSION['flash'] = "Thêm tour thành công!";
        header('Location:?act=tour-list'); exit;
    }

    // ===== SỬA TOUR =====
    public function edit() {
        $id = $_GET['id'] ?? null;
        if (!$id) { header('Location:?act=tour-list'); exit; }

        $tourData = $this->tour->getById($id);
        if (!$tourData) { header('Location:?act=tour-list'); exit; }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'name' => $_POST['name'],
                'price' => $_POST['price'],
                'description' => $_POST['description']
            ];

            // Upload ảnh mới nếu có
            if (!empty($_FILES['image']['name'])) {
                $uploadDir = __DIR__ . '/../../public/uploads/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

                $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $filename = uniqid() . '.' . $ext;
                $target = $uploadDir . $filename;

                if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                    // Xóa ảnh cũ
                    if (!empty($tourData['image']) && file_exists(__DIR__ . '/../../public/' . $tourData['image'])) {
                        unlink(__DIR__ . '/../../public/' . $tourData['image']);
                    }
                    $data['image'] = 'uploads/' . $filename;
                }
            }

            $this->tour->update($id, $data);
            $_SESSION['flash'] = "Cập nhật tour thành công!";
            header('Location:?act=tour-list'); exit;
        }

        $title = "Sửa Tour";
        view('admin.tour.edit', compact('tourData', 'title'));
    }

    // ===== XÓA TOUR =====
    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id) {
            $pdo = getDB();

            // 1️⃣ Xóa log liên quan booking
            $stmt = $pdo->prepare("
                DELETE l 
                FROM booking_status_logs l
                INNER JOIN bookings b ON l.booking_id = b.id
                WHERE b.tour_id = :id
            ");
            $stmt->execute(['id'=>$id]);

            // 2️⃣ Xóa các booking liên quan
            $stmt2 = $pdo->prepare("DELETE FROM bookings WHERE tour_id = :id");
            $stmt2->execute(['id'=>$id]);

            // 3️⃣ Xóa ảnh tour nếu có
            $tourData = $this->tour->getById($id);
            if (!empty($tourData['image']) && file_exists(__DIR__ . '/../../public/' . $tourData['image'])) {
                unlink(__DIR__ . '/../../public/' . $tourData['image']);
            }

            // 4️⃣ Xóa tour
            $this->tour->delete($id);

            $_SESSION['flash'] = "Xóa tour thành công!";
        }

        header('Location:?act=tour-list'); 
        exit;
    }
}
