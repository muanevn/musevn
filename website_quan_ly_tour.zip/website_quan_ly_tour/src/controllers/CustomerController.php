<?php
class CustomerController {

    // Danh sách khách hàng
    public function list() {
        $customerModel = new Customer();
        $customers = $customerModel->getAll();

        view('admin.customer.list', [
            'customers' => $customers,
            'title' => 'Danh sách Khách hàng'
        ]);
    }

    // Form thêm
    public function add() {
        view('admin.customer.add', [
            'title' => "Thêm khách hàng"
        ]);
    }

    // Lưu khách hàng
    public function store() {

        $data = [
            'name'  => $_POST['name'],
            'email' => $_POST['email'],
            'phone' => $_POST['phone']
        ];

        $customer = new Customer();
        $customer->insert($data);

        $_SESSION['flash_message'] = "Thêm khách hàng thành công!";
        redirect('index.php?act=customer-list');
    }

    // Xóa
    public function delete() {
        if (empty($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('index.php?act=customer-list');
        }

        $id = $_GET['id'];

        $customer = new Customer();
        $customer->delete($id);

        $_SESSION['flash_message'] = "Xóa khách hàng thành công!";
        redirect('index.php?act=customer-list');
    }
    public function edit() {
    if (empty($_GET['id']) || !is_numeric($_GET['id'])) {
        redirect('index.php?act=customer-list');
    }

    $id = $_GET['id'];

    $customer = new Customer();
    $data = $customer->find($id);

    if (!$data) {
        redirect('index.php?act=customer-list');
    }

    view('admin.customer.edit', [
        'title' => 'Sửa khách hàng',
        'customer' => $data
    ]);
}
public function update() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        redirect('index.php?act=customer-list');
    }

    $id = $_POST['id'];

    $data = [
        'name'  => $_POST['name'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone']
    ];

    $customer = new Customer();
    $customer->update($id, $data);

    $_SESSION['flash_message'] = "Cập nhật khách hàng thành công!";
    redirect('index.php?act=customer-list');
}

}
