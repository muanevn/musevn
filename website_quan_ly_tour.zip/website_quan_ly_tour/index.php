<?php

// Nạp cấu hình chung của ứng dụng
$config = require __DIR__ . '/config/config.php';

// Nạp các file chứa hàm trợ giúp
require_once __DIR__ . '/src/helpers/helpers.php';
require_once __DIR__ . '/src/helpers/database.php';


// Nạp các file chứa model
require_once __DIR__ . '/src/models/User.php';
require_once __DIR__ . '/src/models/Tour.php';
require_once __DIR__ . '/src/models/Customer.php';
require_once __DIR__ . '/src/models/Vehicle.php';

// Nạp các file chứa controller
require_once __DIR__ . '/src/controllers/HomeController.php';
require_once __DIR__ . '/src/controllers/AuthController.php';
require_once __DIR__ . '/src/controllers/TourController.php';
require_once __DIR__ . '/src/controllers/CustomerController.php';
require_once __DIR__ . '/src/controllers/VehicleController.php';

// Khởi tạo các controller
$homeController      = new HomeController();
$authController      = new AuthController();
$tourController      = new TourController();
$customerController  = new CustomerController();
$vehicleController  = new VehicleController();

// Xác định route dựa trên tham số act (mặc định là trang chủ '/')
$act = $_GET['act'] ?? '/';

// Match route
match ($act) {
    // Trang welcome (cho người chưa đăng nhập)
    '/', 'welcome' => $homeController->welcome(),

    // Trang home
    'home' => $homeController->home(),

    // ===== QUẢN LÝ TOUR =====
    'tour-list'   => $tourController->list(),
    'tour-add'    => $tourController->add(),
    'tour-store'  => ($_SERVER['REQUEST_METHOD'] === 'POST')
                      ? $tourController->store()
                      : $tourController->add(),
    'tour-edit'   => $tourController->edit(),
    'tour-delete' => $tourController->delete(),

    // ===== QUẢN LÝ KHÁCH HÀNG =====
    'customer-list'   => $customerController->list(),
    'customer-add'    => $customerController->add(),
    'customer-store'  => ($_SERVER['REQUEST_METHOD'] === 'POST')
                          ? $customerController->store()
                          : $customerController->add(),
    'customer-edit'   => $customerController->edit(),  // <-- sửa khách hàng
    'customer-update' => ($_SERVER['REQUEST_METHOD'] === 'POST')
                          ? $customerController->update() // <-- lưu cập nhật
                          : redirect('index.php?act=customer-list'),
    'customer-delete' => $customerController->delete(),

    // ===== QUẢN LÝ PHƯƠNG TIỆN =====
'vehicle-list'   => $vehicleController->list(),
'vehicle-create' => $vehicleController->create(),
'vehicle-store'  => ($_SERVER['REQUEST_METHOD'] === 'POST')
                    ? $vehicleController->store()
                    : $vehicleController->create(),
'vehicle-edit'   => $vehicleController->edit(),
'vehicle-update' => ($_SERVER['REQUEST_METHOD'] === 'POST')
                    ? $vehicleController->update()
                    : redirect('index.php?act=vehicle-list'),
'vehicle-delete' => $vehicleController->delete(),

    // ===== AUTH =====
    'login'        => $authController->login(),
    'check-login'  => $authController->checkLogin(),
    'logout'       => $authController->logout(),

    // Đường dẫn không tồn tại
    default => $homeController->notFound(),
};
